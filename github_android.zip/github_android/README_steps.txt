خطوات النشر على Amazon Appstore (بالترتيب)

المرحلة 1: تجهيز مشروع Android Studio
1) افتح Android Studio ثم: New Project ← Empty Views Activity
   - Name: Top100game
   - Package name: com.mohamed.top100game
   - Language: Java
   - Minimum SDK: API 24
2) استبدل ملف MainActivity.java في app/src/main/java/com/mohamed/top100game/ بالملف الموجود في هذا المجلد.
3) استبدل app/src/main/AndroidManifest.xml بالملف الموجود هنا.
4) أنشئ مجلد app/src/main/assets/ وضع فيه ملف index.html من هذا المجلد.
5) استبدل محتوى app/build.gradle بمحتوى build.gradle.txt (احذف السطر التوضيحي الأول).
6) أنشئ الأيقونات: res/mipmap (ic_launcher) من icon-512.png المرفق مع الملفات السابقة، أو اتركها الأيقونة الافتراضية مؤقتاً.

المرحلة 2: إنشاء مفتاح التوقيع (مرة واحدة فقط)
7) Build ← Generate Signed App Bundle / APK ← APK ← Next.
8) Create new... واملأ: مسار الحفظ (احفظه في مكان آمن خارج المشروع)، كلمة مرور، اسم المفتاح top100، مدة 25 سنة.
9) احفظ ملف المفتاح وكلمة المرور في مكان آمن. إن فقدتهما لن تستطيع تحديث التطبيق أبداً.

المرحلة 3: بناء الـAPK الموقّع
10) اختر المفتاح، واختر release، ثم Finish.
11) الملف الناتج: app/release/app-release.apk
   - زيادة رقم الإصدار: غيّر versionCode في build.gradle (مثلاً 2) قبل كل رفع جديد.

المرحلة 4: حساب Amazon
12) أنشئ حساب Amazon (amazon.com) إن لم يكن لديك.
13) ادخل: https://developer.amazon.com/ وسجّل بنفس البريد، وأكمل ملف المطوّر (مجاني).

المرحلة 5: إضافة التطبيق
14) من لوحة المطوّر: Amazon Appstore ← Add a New App.
15) الخطوة 1 Upload Your App File: ارفع app-release.apk.
    - إن ظهر تحذير zipalign فأعد البناء من Android Studio (لا من أداة أخرى).
    - إن ظهر تحذير 64 بت (arm64-v8a) اتبع تعليمات الصفحة.
    - إن ظهر أن اسم الحزمة مستخدم، اختر اسماً آخر وأعد البناء.
16) الخطوة 2 Target: اختر الأجهزة (الافتراضي مناسب).
17) الخطوة 3 Store Listing: الاسم، الوصف (عربي وإنجليزي)، التصنيف (Games)، الأيقونة 512×512، لقطات شاشة، رابط سياسة الخصوصية، بريد الدعم، التقييم العمري.
18) الخطوة 4 Pricing: مجاني، واختر الدول.
19) اضغط Submit ثم انتظر المراجعة. الحالة تظهر في القائمة.

المراجع الرسمية:
- صفحة النشر: https://developer.amazon.com/docs/app-submission/submitting-apps-to-amazon-appstore.html
- المتطلبات: https://developer.amazon.com/docs/app-submission/understanding-submission.html
- لوحة المطوّر: https://developer.amazon.com/
